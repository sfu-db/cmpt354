import pyodbc


def connect_db():
    ODBC_STR = "ODBC_STR"
    return pyodbc.connect(ODBC_STR)


if __name__ == '__main__':
    print(pyodbc.drivers())
    print(connect_db())
